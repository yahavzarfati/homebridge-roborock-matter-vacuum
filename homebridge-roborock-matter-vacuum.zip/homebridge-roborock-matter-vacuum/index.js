'use strict';
const fs = require('fs');
const path = require('path');
const miio = require('miio');

let hap; // reserved for future HAP services if needed
const PLUGIN_NAME = 'homebridge-roborock-matter-vacuum';
const PLATFORM_NAME = 'RoborockPrograms';

const wait = (ms) => new Promise(r => setTimeout(r, ms));

class RoborockProgramsPlatform {
  constructor(log, config, api) {
    this.log = log;
    this.api = api;
    this.cfg = config || {};

    // Config
    this.ip = this.cfg.ip;
    this.token = this.cfg.token;
    this.presets = Array.isArray(this.cfg.presets) ? this.cfg.presets : [];
    this.reconnectMs = this.cfg.reconnectIntervalMs || 15000;
    this.batteryPollSeconds = Number(this.cfg.batteryPollSeconds || 60);
    this.matterCfg = this.cfg.matter || {};
    this.storagePath = api.user.storagePath();
    this.pairingFile = path.join(this.storagePath, 'roborock-matter-pairing.json');

    // State
    this.device = null;
    this.isConnecting = false;
    this.restored = new Map();
    this._pollTimer = null;
    this.matterDevice = null;
    this.matterVacuum = null;

    // Guard: only start when properly configured
    if (!this.ip || !this.token || !this.presets.length) {
      log.warn('[Roborock] Missing ip/token/presets. Plugin will not start until configured.');
      return;
    }

    api.on('didFinishLaunching', async () => {
      await this._connectRoborock();
      await this._startMatterBridge();
      this._startBatteryPolling();
    });

    api.on('shutdown', async () => {
      try {
        if (this._pollTimer) clearInterval(this._pollTimer);
        if (this.matterDevice && this.matterDevice.stop) await this.matterDevice.stop();
        if (this.device && this.device.destroy) this.device.destroy();
      } catch (e) {
        this.log.debug('Shutdown error:', e.message);
      }
    });
  }

  configureAccessory(acc) {
    // Not used (no HAP accessories), but kept for Homebridge expectations
    this.restored.set(acc.UUID, acc);
  }

  async _connectRoborock() {
    if (this.isConnecting || !this.ip || !this.token) return;
    this.isConnecting = true;

    let attempt = 0;
    while (!this.device) {
      attempt++;
      try {
        this.device = await miio.device({ address: this.ip, token: this.token });
        this.log.info(`[Roborock] Connected: ${this.ip}`);
        this.device.on('disconnected', () => {
          this.log.warn('[Roborock] Disconnected; will retry…');
          this.device = null;
          setTimeout(() => this._connectRoborock().catch(() => {}), this.reconnectMs);
        });
      } catch (e) {
        this.log.error(`[Roborock] Connect error (attempt ${attempt}): ${e.message}`);
        await wait(Math.min(this.reconnectMs * attempt, 60000));
      }
    }

    this.isConnecting = false;
  }

  _startBatteryPolling() {
    const intervalMs = Math.max(10, this.batteryPollSeconds) * 1000;
    const poll = async () => {
      if (!this.device) return;
      try {
        const res = await this.device.call('get_prop', ['battery']);
        const pct = Array.isArray(res) ? res[0] : res;
        if (typeof pct === 'number' && this.matterVacuum && this.matterVacuum.setBatteryLevel) {
          this.matterVacuum.setBatteryLevel(pct);
        }
        this.log.debug(`[Battery] ${pct}%`);
      } catch (e) {
        this.log.debug('Battery poll error:', e.message);
      }
    };
    poll();
    this._pollTimer = setInterval(poll, intervalMs);
    this._pollTimer.unref?.();
  }

  async _applyPresetParams(preset) {
    try { if (preset.fanPowerPct != null) await this.device.call('set_custom_mode', [preset.fanPowerPct], { retries: 1 }); } catch { this.log.debug('fanPower not supported'); }
    try { if (preset.waterLevelCode != null) await this.device.call('set_water_box_custom_mode', [preset.waterLevelCode], { retries: 1 }); } catch { this.log.debug('waterLevel not supported'); }
    try { if (preset.mopModeCode != null) await this.device.call('set_mop_mode', [preset.mopModeCode], { retries: 1 }); } catch { /* optional */ }
  }

  async _runPreset(preset) {
    if (!this.device) await this._connectRoborock();
    await this._applyPresetParams(preset);

    switch (preset.mode) {
      case 'segments':
        if (!Array.isArray(preset.segment_ids) || !preset.segment_ids.length) throw new Error('segments: segment_ids missing');
        await this.device.call('app_segment_clean', [preset.segment_ids], { retries: 1 });
        break;
      case 'zoned':
        if (!Array.isArray(preset.zones) || !preset.zones.length) throw new Error('zoned: zones missing');
        await this.device.call('app_zoned_clean', preset.zones, { retries: 1 });
        break;
      case 'start':
        await this.device.call('app_start', [], { retries: 1 });
        break;
      case 'dock':
        await this.device.call('app_charge', [], { retries: 1 });
        break;
      default:
        throw new Error('Unsupported mode: ' + preset.mode);
    }
    this.log.info(`Preset executed: ${preset.name || preset.mode}`);
  }

  async _startMatterBridge() {
    let matter;
    try {
      matter = require('matterbridge');
    } catch {
      this.log.error('Matter dependency not found. Ensure "matterbridge" is installed.');
      return;
    }
    const { createDevice, RobotVacuum } = matter;

    // Persist pairing state
    const persisted = this._loadPairingData();

    this.matterDevice = await createDevice({
      bridge: { name: this.matterCfg.bridgeName || 'Roborock Matter Bridge' },
      storage: {
        get: async (key) => (persisted && persisted[key]) || null,
        set: async (key, value) => {
          const data = this._loadPairingData() || {};
          data[key] = value;
          fs.writeFileSync(this.pairingFile, JSON.stringify(data, null, 2));
        }
      }
    });

    const vacuum = new RobotVacuum({
      name: this.matterCfg.vacuumName || 'Roborock Saros 10 Refill',
      vendorId: 0xFFF1,
      productId: 0x0001
    });

    // Bind core actions
    vacuum.onStartCleaning(async () => {
      try { await this._runPreset({ mode: 'start', name: 'Start' }); } catch (e) { this.log.error('Start failed:', e.message); }
    });
    vacuum.onPauseCleaning(async () => {
      try { await this.device.call('app_pause', [], { retries: 1 }); } catch (e) { this.log.error('Pause failed:', e.message); }
    });
    vacuum.onStopCleaning(async () => {
      try { await this.device.call('app_stop', [], { retries: 1 }); } catch (e) { this.log.error('Stop failed:', e.message); }
    });
    vacuum.onDock(async () => {
      try { await this._runPreset({ mode: 'dock', name: 'Dock' }); } catch (e) { this.log.error('Dock failed:', e.message); }
    });

    // Expose programs
    const names = this.presets.map(p => p.name);
    vacuum.setPrograms(names);
    vacuum.onSelectProgram(async (idx) => {
      const p = this.presets[idx];
      if (p) await this._runPreset(p);
    });

    this.matterVacuum = vacuum;

    await this.matterDevice.addAccessory(vacuum);
    await this.matterDevice.start();

    const pairing = this.matterDevice.getPairingData?.();
    if (pairing?.qrCode) this.log.warn(`[Matter] Scan this QR in Apple Home: ${pairing.qrCode}`);
    if (pairing?.manualCode) this.log.warn(`[Matter] Manual setup code: ${pairing.manualCode}`);
    this.log.info('[Matter] Bridge started. In Home app: Add Accessory → Scan QR.');
  }

  _loadPairingData() {
    try {
      if (fs.existsSync(this.pairingFile)) {
        return JSON.parse(fs.readFileSync(this.pairingFile, 'utf8'));
      }
    } catch (e) {
      this.log.debug('Pairing state load error:', e.message);
    }
    return null;
  }
}

module.exports = (api) => {
  hap = api.hap;
  api.registerPlatform(PLUGIN_NAME, PLATFORM_NAME, RoborockProgramsPlatform);
};

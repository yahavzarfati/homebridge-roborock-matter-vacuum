# Homebridge Roborock Matter Vacuum

Expose your **Roborock Saros 10 Refill** as a **native Matter Robot Vacuum** in Apple Home – with selectable cleaning programs (rooms / zones / start / dock), per-program suction & water level, docking, and battery level. Local control via `miIO` (no cloud).

## Features
- 🧹 Native Robot Vacuum (not a fake TV/fan)
- 🧭 Programs: map your Roborock routines as selectable programs
- ⚡ Per-program fan power & water level (when supported)
- 🔋 Battery updates
- 🔒 Local control only (miIO)
- 🧩 Homebridge UI config (strict validation)

## Requirements
- Node.js ≥ 18, Homebridge ≥ 1.6
- Roborock on LAN (IP + 32-hex token)
- iOS 18+ (Robot Vacuum via Matter)

## Install
### Homebridge UI
Search:
```
homebridge-roborock-matter-vacuum
```
and click **Install**.

### Terminal
```bash
sudo npm install -g homebridge-roborock-matter-vacuum
```

## Configure (Homebridge UI → Plugins → Settings)
Example:
```json
{
  "platform": "RoborockPrograms",
  "ip": "YOUR_ROBOROCK_IP",
  "token": "YOUR_32_HEX_TOKEN",
  "batteryPollSeconds": 60,
  "matter": {
    "bridgeName": "Roborock Matter Bridge",
    "vacuumName": "Roborock Saros 10 Refill"
  },
  "presets": [
    {
      "name": "Living Room",
      "mode": "segments",
      "segment_ids": [
        16
      ],
      "fanPowerPct": 77,
      "waterLevelCode": 202
    },
    {
      "name": "Under Table",
      "mode": "zoned",
      "zones": [
        [
          [
            25200,
            27500,
            28000,
            30500,
            1
          ]
        ]
      ],
      "fanPowerPct": 60,
      "waterLevelCode": 201
    },
    {
      "name": "Whole House",
      "mode": "start"
    },
    {
      "name": "Dock",
      "mode": "dock"
    }
  ]
}
```

## Pairing (Matter)
Restart Homebridge and check logs for a QR:
```
[Matter] Scan this QR in Apple Home: XXXX...
```
Then: **Home → Add Accessory → Scan QR**.

## Notes
- `segment_ids` are Roborock room IDs (get them from logs/Valetudo/other plugins).
- `zones` are in map millimeters: `[x1, y1, x2, y2, repeats]`.
- Some models don’t support mop mode/water level APIs; unsupported commands are safely ignored.
- No telemetry. No analytics. Local only.

## Troubleshooting
- If QR changes on each reboot, ensure Homebridge can write:
  - `<storagePath>/roborock-matter-pairing.json`
- Connection errors: verify IP/TOKEN; plugin retries with backoff.
- Nothing appears in Home? Ensure iOS 18+ with Matter support.

## Changelog
See [CHANGELOG.md](./CHANGELOG.md)

## License
MIT

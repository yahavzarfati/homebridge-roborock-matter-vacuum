# Changelog

## 1.0.0
- Initial public release for Roborock Saros 10 Refill.
- Native Matter Robot Vacuum with programs, battery polling, local miIO.
- Homebridge UI schema (strict).
- Pairing persistence, graceful shutdown, reconnect/backoff.
